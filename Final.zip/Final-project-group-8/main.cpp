#include <iostream>
#include <cstdlib> // for rand() and srand()
#include <ctime>   // for time()

#include "queue.h"
#include "stack.h"

using namespace std;

void classifyWaste(Queue& wasteQueue, Stack& binStack)
 {
    int i = 1;
    int point = 0;
    while(!wasteQueue.isEmpty()) {
	std::string choice;
    	string waste = wasteQueue.dequeue();
	
	std::cout << "\n\n\n";
	std::cout << "(a). General Waste Bin\n";
	std::cout << "(b). Hazardous Waste Bin\n";
	std::cout << "(c). Wet Waster Bin\n";
	std::cout << "(d). Non of the above\n";
    	cout << i << ". "<< waste << ": ";
	cin >> choice;

        if (waste == "Plastic" || waste == "Paper") 
{
            	if(choice == "a")
		{	
			point++;
			cout << "Correct +1";
		}
		else
		{
			cout << "Incorrect";
		}		binStack.push(std::to_string(i) + ". General Waste Bin");
        } 
	else if (waste == "Glass" || waste == "Metal") 
	{	
		if(choice == "b")
		{	
			point++;
			cout << "Correct +1";
		}
		else
		{
			cout << "Incorrect";
		}
            	binStack.push(std::to_string(i)  + ". Hazardous Waste Bin");
        } 
	else if (waste == "Organic") 
	{
	    	if(choice == "c")
		{	
			point++;
			cout << "Correct +1";
		}
		else
		{
			cout << "Incorrect";
		}
            	binStack.push(std::to_string(i) + ". Wet Waste Bin");
        } 
	else 
	{	
		if(choice == "d")
		{	
			point++;
			cout << "Correct +1";
		}
		else
		{
			cout << "Incorrect";
		}		
		binStack.push(std::to_string(i) +  ". Unrecognized waste type!");
        }
	i++;
    }
	
    cout << "\n\n\n" << "Bins matched: " << point << "\n\n\n";
   
    
    Stack temp(binStack.size());
    while (!binStack.isEmpty())temp.push(binStack.pop());
    while (!temp.isEmpty()) {
        cout << temp.pop() << endl;      
 	}
 }
int main() 
{	
	srand(time(0));
    	Stack binAnswerKey(15);

	string wasteTypes[] = {"Plastic", "Paper", "Glass", "Metal", "Organic"};
	Queue sample;
	for(int i=0;i<15;i++)
	{
		sample.enqueue(wasteTypes[rand()%5]);
	}
	classifyWaste(sample, binAnswerKey);

}

