void display(int [],int );
void swap(int &,int &);
void bubblesorting(int a[],int N);

void display(int a[],int N){
        int i;
       for(i=0;i<N;i++)
           cout<<a[i]<<" ";
       cout<<endl;
    
}

void swap(int & x,int &y){
        int temp=y;
        y=x;
        x=temp.
    
}
void bubbleSort(int a[],int N){


}
