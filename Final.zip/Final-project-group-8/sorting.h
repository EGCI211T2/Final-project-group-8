void display(double [],int );
void swap(double &,double &);
void bubblesorting(double a[],int N);

void display(double a[],int N){
        int i;
       for(i=0;i<N;i++)
           cout<<a[i]<<" ";
       cout<<endl;
    
}

void swap(double & x,double &y){
        double temp=y;
        y=x;
        x=temp;
}
void bubbleSort(double a[],int N){


}
